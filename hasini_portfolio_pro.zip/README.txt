
HOW TO USE:

1. Extract folder
2. Open index.html
3. Edit text or add your photo in assets folder
4. Deploy on GitHub Pages or Netlify

Features:
- Responsive design
- Professional layout
- Auto year script
- Clean UI
